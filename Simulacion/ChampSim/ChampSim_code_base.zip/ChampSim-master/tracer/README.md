This directory contains example tracing utilities that create ChampSim traces. It currently contains only one tracer, for use with Intel PIN, but more will be added in the future.

